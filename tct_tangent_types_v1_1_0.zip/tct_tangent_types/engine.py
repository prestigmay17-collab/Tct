# -*- coding: utf-8 -*-
"""
Движок аддона: хранение типа на Action, запись Безье-ручек, живой пересчёт.
"""

import json
import math
import time

import bpy
from bpy.app.handlers import persistent

from . import log, mathcore

CONFIG_KEY = "tcb_config"

_STATE = {
    "busy": False,
    "sig": {},
    "last": 0.0,
    "handler": None,
    "deferred": False,
    "seen": {},
}

LIVE_INTERVAL = 0.15


# ─────────────────────────────────────────────────────────────────────────────
# Доступ к F-Curve (Blender 4.4 со слотами и более старый API)
# ─────────────────────────────────────────────────────────────────────────────
def iter_action_fcurves(action):
    if action is None:
        return
    fcurves = getattr(action, "fcurves", None)
    if fcurves is not None:
        try:
            if len(fcurves):
                for fc in fcurves:
                    yield fc
                return
        except Exception:
            pass
    for layer in getattr(action, "layers", []) or []:
        for strip in getattr(layer, "strips", []) or []:
            for bag in getattr(strip, "channelbags", []) or []:
                for fc in getattr(bag, "fcurves", []) or []:
                    yield fc


def curve_key(fcurve):
    return "%s[%d]" % (fcurve.data_path, fcurve.array_index)


def object_actions(obj):
    animation = obj.animation_data
    if animation is None:
        return []
    actions = []
    if getattr(animation, "action", None) is not None:
        actions.append(animation.action)
    for track in getattr(animation, "nla_tracks", []) or []:
        for strip in getattr(track, "strips", []) or []:
            action = getattr(strip, "action", None)
            if action is not None:
                actions.append(action)
    return actions


# ─────────────────────────────────────────────────────────────────────────────
# Конфигурация на Action (одна строка JSON — переносится вместе с файлом)
# ─────────────────────────────────────────────────────────────────────────────
def config_get(action):
    if action is None:
        return {}
    raw = action.get(CONFIG_KEY)
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def config_set(action, data):
    if action is None:
        return
    if not data:
        try:
            del action[CONFIG_KEY]
        except Exception:
            pass
        return
    action[CONFIG_KEY] = json.dumps(data, ensure_ascii=False)


def get_entry(action, fcurve):
    return config_get(action).get(curve_key(fcurve))


def set_type(fcurve, kind, t=0.0, c=0.0, b=0.0, ends="flat"):
    action = getattr(fcurve, "id_data", None)
    if action is None:
        return False
    # В Blender 5.0 у Action может не быть .fcurves (только слои) — это нормально.
    if not (hasattr(action, "fcurves") or hasattr(action, "layers")):
        return False
    data = config_get(action)
    data[curve_key(fcurve)] = {
        "type": kind,
        "t": mathcore.clamp_unit(t),
        "c": mathcore.clamp_unit(c),
        "b": mathcore.clamp_unit(b),
        "ends": ends if ends in mathcore.END_MODES else "flat",
    }
    config_set(action, data)
    return True


def clear_type(fcurve):
    action = getattr(fcurve, "id_data", None)
    data = config_get(action)
    key = curve_key(fcurve)
    if key in data:
        del data[key]
        config_set(action, data)
        return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
# Применение типа к одной F-Curve
# ─────────────────────────────────────────────────────────────────────────────
def apply_fcurve(fcurve, entry, force=False, tag=""):
    """Ставит Безье-ручки по типу. Возвращает 'ok' | 'short' | 'dup' | 'skip'."""
    points = fcurve.keyframe_points
    count = len(points)
    name = "%s%s" % (tag, curve_key(fcurve))
    if count < 2:
        log.add(2, "  %s: пропуск, меньше 2 ключей (%d)" % (name, count))
        return "short"

    order = sorted(range(count), key=lambda i: points[i].co.x)
    times = [float(points[i].co.x) for i in order]
    values = [float(points[i].co.y) for i in order]
    for i in range(1, count):
        if times[i] - times[i - 1] <= 1e-6:
            log.add(2, "  %s: пропуск, два ключа в одном кадре (%.4f)"
                    % (name, times[i]))
            return "dup"

    kind = (entry or {}).get("type")
    if not kind or kind not in mathcore.TYPE_LABELS:
        log.add(2, "  %s: пропуск, неизвестный тип %r" % (name, kind))
        return "skip"

    params = {"t": entry.get("t", 0.0), "c": entry.get("c", 0.0),
              "b": entry.get("b", 0.0), "ends": entry.get("ends", "flat")}
    try:
        in_s, out_s = mathcore.slopes(times, values, kind, params)
    except ValueError as exc:
        log.add(1, "  %s: ОШИБКА расчёта наклонов: %s" % (name, exc))
        return "skip"

    handles = mathcore.handles_for(times, values, in_s, out_s)
    log.add(2, "  %s: тип=%s ключей=%d T=%.2f C=%.2f B=%.2f края=%s" % (
        name, kind, count, params["t"], params["c"], params["b"],
        params["ends"]))

    # Ручку, которую аниматор поставил сам (тип ALIGNED / VECTOR), не трогаем:
    # иначе живой пересчёт воюет с пользователем и ручка «отпрыгивает» назад
    # на каждом обновлении сцены. FREE — наша, её можно перезаписывать.
    detail = log.level() >= 2
    for pos, index in enumerate(order):
        point = points[index]
        if point.interpolation == "CONSTANT":
            if detail and pos < 40:
                log.add(2, "    k%d t=%.3f: CONSTANT, ручки не трогаю" % (
                    pos, times[pos]))
            continue
        dx_in, dy_in, dx_out, dy_out = handles[pos]
        point.interpolation = "BEZIER"
        note = ""
        if point.handle_left_type in ("FREE", "AUTO", "AUTO_CLAMPED"):
            point.handle_left_type = "FREE"
            point.handle_left = (times[pos] - dx_in, values[pos] - dy_in)
        else:
            note += " левая=%s(не тронута)" % point.handle_left_type
        if point.handle_right_type in ("FREE", "AUTO", "AUTO_CLAMPED"):
            point.handle_right_type = "FREE"
            point.handle_right = (times[pos] + dx_out, values[pos] + dy_out)
        else:
            note += " правая=%s(не тронута)" % point.handle_right_type
        if detail and pos < 40:
            log.add(2, "    k%d t=%.3f v=%.4f  вх=%.4f исх=%.4f  "
                       "ручки dx=%.3f/%.3f%s" % (
                           pos, times[pos], values[pos], in_s[pos],
                           out_s[pos], dx_in, dx_out, note))
    if detail and count > 40:
        log.add(2, "    ... ещё %d ключей (в журнал не выводятся)" % (count - 40))

    fcurve.update()
    return "ok"



def apply_action(action, force=False):
    data = config_get(action)
    if not data:
        return {"applied": 0, "skipped": 0}
    applied = skipped = 0
    for fcurve in iter_action_fcurves(action):
        entry = data.get(curve_key(fcurve))
        if not entry:
            continue
        result = apply_fcurve(fcurve, entry, force,
                              tag="[%s] " % action.name)
        if result == "ok":
            applied += 1
        else:
            skipped += 1
    return {"applied": applied, "skipped": skipped}


def apply_objects(objects, force=False):
    total = {"applied": 0, "skipped": 0}
    for obj in objects:
        for action in object_actions(obj):
            stats = apply_action(action, force)
            total["applied"] += stats["applied"]
            total["skipped"] += stats["skipped"]
    return total


# ─────────────────────────────────────────────────────────────────────────────
# Выбор кривых в контексте
# ─────────────────────────────────────────────────────────────────────────────
def context_fcurves(context):
    """Выделенные кривые Graph Editor; иначе все кривые выделенных объектов.

    У SpaceGraphEditor нет свойства action (оно только у Dope Sheet), поэтому
    берём члены контекста Graph Editor: выделенные, потом видимые кривые."""
    space = getattr(context, "space_data", None)
    if space is not None and getattr(space, "type", "") == "GRAPH_EDITOR":
        for attr in ("selected_editable_fcurves", "selected_visible_fcurves",
                     "visible_fcurves"):
            try:
                found = getattr(context, attr, None)
                curves = list(found) if found else []
            except Exception:
                curves = []
            if curves:
                return curves

    curves = []
    for obj in context.selected_objects or ():
        for action in object_actions(obj):
            curves.extend(iter_action_fcurves(action))
    return curves


def context_actions(context):
    actions = []
    for fcurve in context_fcurves(context):
        action = getattr(fcurve, "id_data", None)
        if action is not None and action not in actions:
            actions.append(action)
    return actions


# ─────────────────────────────────────────────────────────────────────────────
# Ретайм
# ─────────────────────────────────────────────────────────────────────────────
def retime(context, factor, pivot=None):
    """Масштабирует время ключей. factor<1 — быстрее.

    pivot по умолчанию — первый ключ ВСЕГО выделения, а не каждой кривой:
    иначе каналы, начинающиеся в разных кадрах, съезжают друг относительно
    друга (кривая X с ключами [0,10] и кривая Y с [5,15] после ×0.5 давали
    X=[0,5], Y=[5,10] вместо [2.5,7.5] — позы рассинхронизировались).
    """
    factor = float(factor)
    if factor <= 0:
        raise ValueError("factor должен быть > 0")
    curves = context_fcurves(context)
    if not curves:
        log.add(1, "ретайм: нет кривых")
        return 0

    if pivot is None:
        starts = [fc.keyframe_points[0].co.x
                  for fc in curves if len(fc.keyframe_points)]
        if not starts:
            return 0
        base = min(starts)
    else:
        base = float(pivot)

    log.add(1, "ретайм: ×%.4g, кривых %d, точка отсчёта кадр %.3f"
            % (factor, len(curves), base))
    for fcurve in curves:
        if not fcurve.keyframe_points:
            continue
        for point in fcurve.keyframe_points:
            point.co.x = base + (point.co.x - base) * factor
            point.handle_left.x = base + (point.handle_left.x - base) * factor
            point.handle_right.x = base + (point.handle_right.x - base) * factor
        fcurve.update()
    for action in context_actions(context):
        apply_action(action, force=False)
    for fcurve in curves:
        action = getattr(fcurve, "id_data", None)
        if action is not None:
            _STATE["seen"][(action.as_pointer(), curve_key(fcurve))] = \
                _signature(fcurve)
    return len(curves)



# ─────────────────────────────────────────────────────────────────────────────
# Живой пересчёт
# ─────────────────────────────────────────────────────────────────────────────
def _playing():
    screen = getattr(bpy.context, "screen", None)
    return bool(getattr(screen, "is_animation_playing", False))


def _signature(fcurve):
    return tuple((round(kp.co.x, 4), round(kp.co.y, 6))
                 for kp in fcurve.keyframe_points)


def scene_params(scene):
    return {
        "t": getattr(scene, "tcb_t", 0.0),
        "c": getattr(scene, "tcb_c", 0.0),
        "b": getattr(scene, "tcb_b", 0.0),
        "ends": getattr(scene, "tcb_ends", "flat"),
    }


def is_enabled(scene=None):
    """Главный выключатель аддона (кнопка в панели)."""
    if scene is None:
        scene = getattr(bpy.context, "scene", None)
    return bool(getattr(scene, "tcb_enabled", True))


def on_enabled_changed(scene):
    """update-колбэк кнопки. При включении забываем, что видели раньше:
    правки, сделанные пока аддон был выключен, не должны сразу превращаться
    в автоназначение типа."""
    on = is_enabled(scene)
    if on:
        _STATE["seen"].clear()
    log.add(1, "=== АДДОН %s (сцена '%s') ===" % (
        "ВКЛЮЧЁН" if on else "ВЫКЛЮЧЕН", getattr(scene, "name", "?")))
    log.flush()
    if on:
        _schedule(0.0)


def _schedule(delay):
    """Один таймер за раз. Запись в F-Curve идёт в таймере, а не внутри
    depsgraph_update_post: там Blender обходит граф, и правка кривых
    (особенно при копипасте/перетаскивании ключей) может уронить процесс."""
    if _STATE["deferred"]:
        return
    _STATE["deferred"] = True
    bpy.app.timers.register(_run_deferred, first_interval=max(0.0, delay))


@persistent
def _deferred_tick(*args):
    """Хендлер depsgraph_update_post (зовётся как fn(scene, depsgraph)).

    @persistent обязателен: без него Blender снимает хендлер при загрузке
    другого .blend, и живой пересчёт молча умирает до перевключения аддона.
    В журнал отсюда не пишем: событий десятки в секунду."""
    scene = args[0] if args and hasattr(args[0], "tcb_enabled") else None
    if not is_enabled(scene):
        return
    _schedule(0.0)


@persistent
def _on_load(*args):
    """Загружен другой файл: указатели на Action теперь другие."""
    _STATE["sig"].clear()
    _STATE["seen"].clear()
    _STATE["deferred"] = False
    log.add(1, "=== файл загружен, кэш пересчёта сброшен ===")
    log.flush()


def _run_deferred():
    _STATE["deferred"] = False
    wait = None
    try:
        wait = _live_tick()
    except Exception:
        import traceback
        log.add(1, "ОШИБКА в тике:\n" + traceback.format_exc())
        traceback.print_exc()
    log.flush()
    if wait:
        # событие пришло слишком рано после прошлого пересчёта: не
        # выбрасываем его, а повторяем позже, иначе после быстрого
        # перетаскивания последняя правка остаётся без пересчёта
        _schedule(wait)
    return None          # одноразовый таймер


def _live_tick():
    """Возвращает None, либо секунды до повтора (если пришли слишком рано)."""
    if _STATE["busy"]:
        return None
    scene = bpy.context.scene
    if scene is None:
        return None
    if not is_enabled(scene):
        log.add(2, "тик: аддон выключен")
        return None
    if getattr(scene, "tcb_live", True) is False:
        log.add(2, "тик: живой пересчёт выключен")
        return None
    if _playing():
        log.add(2, "тик: идёт проигрывание, пропуск")
        return None
    now = time.time()
    since = now - _STATE["last"]
    if since < LIVE_INTERVAL:
        wait = LIVE_INTERVAL - since + 0.01
        log.add(2, "тик: слишком рано, повтор через %.2f с" % wait)
        return wait
    _STATE["last"] = now
    started = time.perf_counter()

    # Только выделенные объекты (обход всей сцены тормозил на сотнях объектов).
    objects = list(bpy.context.selected_objects or ())
    if not objects:
        log.add(2, "тик: нет выделенных объектов")
        return None

    auto = getattr(scene, "tcb_auto", True)
    active = getattr(scene, "tcb_active", "maya_auto")
    if active not in mathcore.TYPE_LABELS:
        auto = False
    params = scene_params(scene)

    # Сначала СОБИРАЕМ список, потом пишем: paste/перетаскивание перестраивают
    # коллекции F-Curve на ходу, мутировать их внутри цикла нельзя.
    snapshot = []
    examined = 0
    for obj in objects:
        for action in object_actions(obj):
            data = config_get(action)
            for fcurve in list(iter_action_fcurves(action)):
                examined += 1
                # Имя Action не уникально (Exporter.001), ключ — сам блок данных.
                key = (action.as_pointer(), curve_key(fcurve))
                sig = _signature(fcurve)
                entry = data.get(curve_key(fcurve))
                label = "%s/%s" % (obj.name, curve_key(fcurve))
                if entry:
                    if _STATE["sig"].get(key) != sig:
                        snapshot.append((key, fcurve, entry, False, label))
                    continue
                # Кривая без типа. Новый ключ / новая кривая: если автотип
                # включён и кривую правили после того, как мы её увидели, —
                # даём ей активный тип, чтобы кривая не была «рваной».
                # Нетронутые кривые (импорт, чужая анимация) не трогаем.
                prev = _STATE["seen"].get(key)
                _STATE["seen"][key] = sig
                if prev is None:
                    log.add(2, "тик: впервые вижу %s (%d ключей), запомнил"
                            % (label, len(fcurve.keyframe_points)))
                elif (auto and prev != sig
                        and len(fcurve.keyframe_points) >= 2):
                    snapshot.append((key, fcurve, None, True, label))
    if not snapshot:
        log.add(2, "тик: изменений нет (кривых проверено: %d)" % examined)
        return None

    log.add(1, "тик: к пересчёту %d кривых (проверено %d)"
            % (len(snapshot), examined))
    done = assigned = failed = 0
    _STATE["busy"] = True
    try:
        for key, fcurve, entry, assign, label in snapshot:
            try:
                if not fcurve.id_data or not fcurve.keyframe_points:
                    continue
                if assign:
                    if not set_type(fcurve, active, **params):
                        log.add(1, "  %s: не удалось назначить тип" % label)
                        failed += 1
                        continue
                    entry = get_entry(fcurve.id_data, fcurve)
                    if not entry:
                        failed += 1
                        continue
                    assigned += 1
                    log.add(1, "  АВТОТИП %s -> %s (ключей: %d)" % (
                        label, active, len(fcurve.keyframe_points)))
                else:
                    log.add(1, "  пересчёт %s (%s, ключей: %d)" % (
                        label, entry.get("type"), len(fcurve.keyframe_points)))
                _STATE["sig"][key] = _signature(fcurve)
                status = apply_fcurve(fcurve, entry, force=False,
                                      tag="%s " % label)
                if status != "ok":
                    log.add(1, "  %s: результат '%s'" % (label, status))
                    failed += 1
                else:
                    done += 1
                _STATE["sig"][key] = _signature(fcurve)
                _STATE["seen"][key] = _STATE["sig"][key]
            except (ReferenceError, RuntimeError) as exc:
                log.add(1, "  %s: кривая пропала во время записи (%s)"
                        % (label, exc))
                continue
    finally:
        _STATE["busy"] = False
    log.add(1, "тик готов: пересчитано %d, автотип %d, проблем %d, %.1f мс"
            % (done, assigned, failed,
               (time.perf_counter() - started) * 1000.0))
    return None


def register_handler():
    """Хендлер только ПЛАНИРУЕТ пересчёт; запись идёт в таймере."""
    handlers = bpy.app.handlers
    if _deferred_tick not in handlers.depsgraph_update_post:
        handlers.depsgraph_update_post.append(_deferred_tick)
    if _on_load not in handlers.load_post:
        handlers.load_post.append(_on_load)
    _STATE["handler"] = _deferred_tick
    log.add(1, "=== TCT зарегистрирован, хендлеры подключены ===")
    log.flush()


def unregister_handler():
    handlers = bpy.app.handlers
    if _deferred_tick in handlers.depsgraph_update_post:
        handlers.depsgraph_update_post.remove(_deferred_tick)
    if _on_load in handlers.load_post:
        handlers.load_post.remove(_on_load)
    _STATE["handler"] = None
    _STATE["sig"].clear()
    _STATE["seen"].clear()
    _STATE["deferred"] = False
    try:
        if bpy.app.timers.is_registered(_run_deferred):
            bpy.app.timers.unregister(_run_deferred)
    except Exception:
        pass
    log.add(1, "=== TCT выгружен, хендлеры сняты ===")
    log.flush()


# ─────────────────────────────────────────────────────────────────────────────
# Диагностика
# ─────────────────────────────────────────────────────────────────────────────
def diagnose(context):
    """Сводка по выделению: сколько кривых, какие типы, сколько без ключей."""
    curves = context_fcurves(context)
    buckets = {}
    types = {}
    for fcurve in curves:
        action = getattr(fcurve, "id_data", None)
        entry = (config_get(action).get(curve_key(fcurve)) if action else None) or {}
        kind = entry.get("type")
        if len(fcurve.keyframe_points) < 2:
            buckets["меньше 2 ключей"] = buckets.get("меньше 2 ключей", 0) + 1
        elif not kind:
            buckets["без типа"] = buckets.get("без типа", 0) + 1
        else:
            buckets["управляется типом"] = buckets.get("управляется типом", 0) + 1
            types[kind] = types.get(kind, 0) + 1
    return {"curves": len(curves), "buckets": buckets, "types": types}
