# -*- coding: utf-8 -*-
"""Операторы, панели и меню аддона."""

import bpy
from bpy.props import FloatProperty, StringProperty

from . import engine, log, mathcore

MENU_TARGETS = (
    "GRAPH_MT_context_menu",
    "GRAPH_MT_channel",
    "GRAPH_MT_key",
    "GRAPH_EDITOR_MT_context_menu",
    "GRAPH_EDITOR_MT_channel",
    "GRAPH_EDITOR_MT_edit",
    "GRAPH_EDITOR_MT_fcurve",
    "VIEW3D_MT_object",
)


def _params(context):
    return engine.scene_params(context.scene)


def _guard(op, context):
    """Пока аддон выключен кнопкой, операторы, которые правят кривые, не работают."""
    if engine.is_enabled(context.scene):
        return True
    op.report({"WARNING"}, "TCT выключен: включи кнопку вверху панели")
    log.add(1, "ОПЕРАТОР %s отклонён: аддон выключен" % op.bl_idname)
    log.flush()
    return False


class TCB_OT_set_type(bpy.types.Operator):
    """Назначить тип касательных выбранным кривым"""

    bl_idname = "tcb.set_type"
    bl_label = "TCT: тип касательных"
    bl_options = {"REGISTER", "UNDO"}

    kind: StringProperty(default="maya_auto")

    def execute(self, context):
        if not _guard(self, context):
            return {"CANCELLED"}
        curves = engine.context_fcurves(context)
        if not curves:
            self.report({"WARNING"}, "TCT: нет выбранных кривых")
            log.add(1, "ОПЕРАТОР set_type(%s): нет выбранных кривых" % self.kind)
            log.flush()
            return {"CANCELLED"}
        params = _params(context)
        log.add(1, "ОПЕРАТОР set_type: тип=%s кривых=%d T=%.2f C=%.2f B=%.2f "
                   "края=%s" % (self.kind, len(curves), params["t"],
                                params["c"], params["b"], params["ends"]))
        applied = 0
        for fcurve in curves:
            if len(fcurve.keyframe_points) < 2:
                log.add(2, "  %s: пропуск, меньше 2 ключей" %
                        engine.curve_key(fcurve))
                continue
            engine.set_type(fcurve, self.kind, **params)
            if hasattr(context.scene, "tcb_active"):
                context.scene.tcb_active = self.kind
            action = getattr(fcurve, "id_data", None)
            entry = engine.config_get(action).get(engine.curve_key(fcurve))
            if engine.apply_fcurve(fcurve, entry, force=True,
                                   tag="[%s] " % action.name) == "ok":
                applied += 1
        log.add(1, "  итог: применено к %d из %d кривых" % (applied, len(curves)))
        log.flush()
        self.report({"INFO"}, "TCT: %s — %d кривых" % (
            mathcore.TYPE_LABELS.get(self.kind, self.kind), applied))
        return {"FINISHED"}


class TCB_OT_apply(bpy.types.Operator):
    """Пересчитать касательные по сохранённым типам"""

    bl_idname = "tcb.apply"
    bl_label = "TCT: пересчитать"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if not _guard(self, context):
            return {"CANCELLED"}
        stats = {"applied": 0, "skipped": 0}
        actions = engine.context_actions(context)
        log.add(1, "ОПЕРАТОР apply: Action в выборке: %d" % len(actions))
        for action in actions:
            result = engine.apply_action(action, force=True)
            stats["applied"] += result["applied"]
            stats["skipped"] += result["skipped"]
        log.add(1, "  итог: обновлено %d, пропущено %d"
                % (stats["applied"], stats["skipped"]))
        log.flush()
        self.report({"INFO"}, "TCT: обновлено %d, пропущено %d"
                    % (stats["applied"], stats["skipped"]))
        return {"FINISHED"}


class TCB_OT_clear(bpy.types.Operator):
    """Снять тип с выбранных кривых"""

    bl_idname = "tcb.clear"
    bl_label = "TCT: снять тип"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        count = 0
        curves = engine.context_fcurves(context)
        for fcurve in curves:
            if engine.clear_type(fcurve):
                count += 1
                log.add(2, "  снят тип с %s" % engine.curve_key(fcurve))
        log.add(1, "ОПЕРАТОР clear: тип снят с %d из %d кривых"
                % (count, len(curves)))
        log.flush()
        self.report({"INFO"}, "TCT: тип снят с %d кривых" % count)
        return {"FINISHED"}


class TCB_OT_retime(bpy.types.Operator):
    """Изменить скорость анимации (масштаб времени ключей)"""

    bl_idname = "tcb.retime"
    bl_label = "TCT: скорость анимации"
    bl_options = {"REGISTER", "UNDO"}

    factor: FloatProperty(name="Скорость ×", default=1.0, min=0.01, max=100.0)

    def execute(self, context):
        if not _guard(self, context):
            return {"CANCELLED"}
        log.add(1, "ОПЕРАТОР retime: factor=%.4g" % self.factor)
        try:
            count = engine.retime(context, self.factor)
        except ValueError as exc:
            log.add(1, "  ОШИБКА: %s" % exc)
            log.flush()
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        log.add(1, "  итог: кривых %d" % count)
        log.flush()
        self.report({"INFO"}, "TCT: скорость ×%.3g, кривых %d" % (self.factor, count))
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class TCB_OT_diagnose(bpy.types.Operator):
    """Показать, какие кривые управляются типом (только чтение)"""

    bl_idname = "tcb.diagnose"
    bl_label = "TCT: диагностика"
    bl_options = {"REGISTER"}

    def execute(self, context):
        info = engine.diagnose(context)
        text = "кривых: %d | %s | типы: %s" % (
            info["curves"], info["buckets"], info["types"])
        print("[TCT] " + text)
        log.add(1, "ОПЕРАТОР diagnose: " + text)
        log.flush()
        self.report({"INFO"}, "TCT: кривых %d — подробности в журнале" % info["curves"])
        return {"FINISHED"}


class TCB_OT_selftest(bpy.types.Operator):
    """Проверить математику на временных кривых"""

    bl_idname = "tcb.selftest"
    bl_label = "TCT: самопроверка"
    bl_options = {"REGISTER"}

    def execute(self, context):
        from . import tests
        log.add(1, "ОПЕРАТОР selftest: старт")
        ok = tests.run(verbose=True)
        log.add(1, "  итог: самопроверка %s" % ("пройдена" if ok else "ПРОВАЛЕНА"))
        log.flush()
        self.report({"INFO"} if ok else {"WARNING"},
                    "TCT: самопроверка %s" % ("пройдена" if ok else "провалена"))
        return {"FINISHED"}


class TCB_OT_toggle_live(bpy.types.Operator):
    """Включить/выключить живой пересчёт"""

    bl_idname = "tcb.toggle_live"
    bl_label = "TCT: живой пересчёт"
    bl_options = {"REGISTER"}

    def execute(self, context):
        context.scene.tcb_live = not context.scene.tcb_live
        log.add(1, "живой пересчёт: %s" % ("вкл" if context.scene.tcb_live else "выкл"))
        log.flush()
        return {"FINISHED"}


class TCB_OT_log_show(bpy.types.Operator):
    """Показать журнал TCT_log в Text Editor"""

    bl_idname = "tcb.log_show"
    bl_label = "Показать журнал"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if log.show(context):
            return {"FINISHED"}
        self.report({"INFO"}, "Открой Text Editor и выбери текст «%s»" % log.TEXT_NAME)
        return {"FINISHED"}


class TCB_OT_log_clear(bpy.types.Operator):
    """Очистить журнал TCT_log"""

    bl_idname = "tcb.log_clear"
    bl_label = "Очистить журнал"
    bl_options = {"REGISTER"}

    def execute(self, context):
        log.clear()
        log.add(1, "журнал очищен")
        log.flush()
        return {"FINISHED"}


# ─────────────────────────────────────────────────────────────────────────────
# Панели
# ─────────────────────────────────────────────────────────────────────────────
def _draw_power(layout, scene):
    on = scene.tcb_enabled
    row = layout.row()
    row.scale_y = 1.6
    row.alert = not on
    row.prop(scene, "tcb_enabled", toggle=True,
             text="TCT ВКЛЮЧЁН" if on else "TCT ВЫКЛЮЧЕН",
             icon="PLAY" if on else "PAUSE")


def _draw_log(layout, scene):
    box = layout.box()
    box.label(text="Журнал (Text Editor → «%s»)" % log.TEXT_NAME)
    box.prop(scene, "tcb_log_level", text="")
    row = box.row(align=True)
    row.operator("tcb.log_show", icon="TEXT")
    row.operator("tcb.log_clear", icon="TRASH")


class TCB_PT_graph(bpy.types.Panel):
    bl_label = "TCT — типы касательных"
    bl_space_type = "GRAPH_EDITOR"
    bl_region_type = "UI"
    bl_category = "TCT"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        _draw_power(layout, scene)

        body = layout.column()
        body.enabled = scene.tcb_enabled

        body.label(text="Тип для выделенных:")
        column = body.column(align=True)
        for kind in mathcore.TYPE_ORDER:
            column.operator("tcb.set_type", text=mathcore.TYPE_LABELS[kind]).kind = kind

        box = body.box()
        box.label(text="Параметры TCB")
        box.prop(scene, "tcb_t", text="Tension")
        box.prop(scene, "tcb_c", text="Continuity")
        box.prop(scene, "tcb_b", text="Bias")
        box.prop(scene, "tcb_ends", text="Крайние ключи")

        body.separator()
        body.operator("tcb.apply", icon="FILE_REFRESH")
        body.operator("tcb.clear", icon="X")
        body.operator("tcb.retime", icon="TIME")
        body.prop(scene, "tcb_live", text="Живой пересчёт")
        auto = body.box()
        auto.prop(scene, "tcb_auto", text="Тип для новых ключей")
        sub = auto.column()
        sub.active = scene.tcb_auto
        sub.prop(scene, "tcb_active", text="")

        layout.separator()
        _draw_log(layout, scene)
        layout.operator("tcb.diagnose", icon="INFO")
        layout.operator("tcb.selftest", icon="CHECKMARK")


class TCB_PT_view3d(bpy.types.Panel):
    bl_label = "TCT — типы касательных"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "TCT"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        _draw_power(layout, scene)

        body = layout.column()
        body.enabled = scene.tcb_enabled
        for kind in mathcore.TYPE_ORDER:
            body.operator("tcb.set_type", text=mathcore.TYPE_LABELS[kind]).kind = kind
        body.separator()
        body.operator("tcb.apply", icon="FILE_REFRESH")
        body.prop(scene, "tcb_live", text="Живой пересчёт")
        body.prop(scene, "tcb_auto", text="Тип для новых ключей")
        body.prop(scene, "tcb_active", text="")

        layout.separator()
        _draw_log(layout, scene)


# ─────────────────────────────────────────────────────────────────────────────
# Меню
# ─────────────────────────────────────────────────────────────────────────────
def _menu_draw(self, context):
    layout = self.layout
    layout.separator()
    for kind in mathcore.TYPE_ORDER:
        op = layout.operator("tcb.set_type", text="TCT: " + mathcore.TYPE_LABELS[kind])
        op.kind = kind
    layout.separator()
    layout.operator("tcb.apply", text="TCT: пересчитать")
    layout.operator("tcb.retime", text="TCT: скорость…")
    layout.operator("tcb.clear", text="TCT: снять тип")


_REGISTERED_MENUS = []


def register_menus():
    global _REGISTERED_MENUS
    _REGISTERED_MENUS = []
    for name in MENU_TARGETS:
        target = getattr(bpy.types, name, None)
        if target is None:
            continue
        try:
            target.append(_menu_draw)
            _REGISTERED_MENUS.append(target)
        except Exception:
            pass
    log.add(1, "меню: подключено %d из %d (%s)" % (
        len(_REGISTERED_MENUS), len(MENU_TARGETS),
        ", ".join(t.__name__ for t in _REGISTERED_MENUS) or "нет"))


def unregister_menus():
    for target in _REGISTERED_MENUS:
        try:
            target.remove(_menu_draw)
        except Exception:
            pass
    _REGISTERED_MENUS.clear()
