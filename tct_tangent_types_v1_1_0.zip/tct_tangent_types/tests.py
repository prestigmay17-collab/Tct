# -*- coding: utf-8 -*-
"""Самопроверка аддона: строит временные кривые и сверяет с формулой."""

import bpy

from . import engine, log, mathcore

TIMES = [1.0, 8.0, 20.0, 26.0]
VALUES = [0.0, 5.0, 2.0, 8.0]


def _check(results, name, ok, detail=""):
    results.append((name, bool(ok)))
    line = "%-46s %s  %s" % (name, "OK  " if ok else "FAIL", detail)
    print("[TCT] " + line)
    log.add(1, "  самопроверка: " + line)
    return ok


def _make_curve():
    obj = bpy.data.objects.new("tctSelftest", None)
    bpy.context.scene.collection.objects.link(obj)
    for frame, value in zip(TIMES, VALUES):
        obj.location.x = value
        obj.keyframe_insert("location", index=0, frame=frame)
    action = obj.animation_data.action
    curves = [fc for fc in engine.iter_action_fcurves(action) if fc.array_index == 0]
    return obj, action, curves[0]


def run(verbose=True):
    results = []
    obj, action, fcurve = _make_curve()
    try:
        _check(results, "3D-курс создан", len(fcurve.keyframe_points) == 4,
               "%d ключей" % len(fcurve.keyframe_points))

        for kind in mathcore.TYPE_ORDER:
            params = {"t": 0.3, "c": 0.2, "b": -0.1} if kind == "tcb" else {}
            engine.set_type(fcurve, kind, **params)
            entry = engine.config_get(action).get(engine.curve_key(fcurve))
            status = engine.apply_fcurve(fcurve, entry, force=True)
            in_s, out_s = mathcore.slopes(TIMES, VALUES, kind, params)
            worst = 0.0
            x = TIMES[0]
            while x <= TIMES[-1] + 1e-9:
                worst = max(worst, abs(fcurve.evaluate(x) - mathcore.hermite(
                    x, TIMES, VALUES, in_s, out_s)))
                x += 0.25
            _check(results, "%s: кривая == формула" % kind,
                   status == "ok" and worst < 1e-4, "max=%.2e" % worst)

        _check(results, "ключи стали BEZIER",
               all(kp.interpolation == "BEZIER" for kp in fcurve.keyframe_points))
        _check(results, "ручки FREE",
               all(kp.handle_left_type == "FREE" and kp.handle_right_type == "FREE"
                   for kp in fcurve.keyframe_points))

        config = engine.config_get(action)
        _check(results, "тип хранится на Action",
               config.get(engine.curve_key(fcurve), {}).get("type") == "tcb")

        before = fcurve.evaluate(14.0)
        engine.clear_type(fcurve)
        _check(results, "clear_type снимает тип",
               engine.curve_key(fcurve) not in engine.config_get(action))
        _check(results, "кривая после снятия не изменилась",
               abs(fcurve.evaluate(14.0) - before) < 1e-6)
    finally:
        bpy.data.objects.remove(obj, do_unlink=True)

    if verbose:
        total = len(results)
        good = sum(1 for _n, ok in results if ok)
        print("[TCT] ИТОГ: %d/%d" % (good, total))
    return all(ok for _n, ok in results)


if __name__ == "__main__":
    run()
