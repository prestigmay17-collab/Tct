# -*- coding: utf-8 -*-
"""
Журнал работы аддона в текстовом блоке «TCT_log» (виден в Text Editor).

Уровни (Scene.tcb_log_level): off / basic (основное) / verbose (подробно).
Строки копятся в буфере и пишутся одним куском в конце тика или оператора:
запись в текстовый блок на каждую строку была бы медленной. Подряд
идущие одинаковые сообщения сворачиваются в «повторено ещё ×N», иначе
пустые тики забили бы журнал. Журнал не растёт бесконечно: при превышении
MAX_LINES старые строки отбрасываются.
"""

import time

import bpy

TEXT_NAME = "TCT_log"
MAX_LINES = 6000
TRIM_TO = 4000
MAX_BUFFER = 30000

LEVELS = {"off": 0, "basic": 1, "verbose": 2}

_buf = []
_last = {"msg": None, "count": 0}


def _scene():
    return getattr(bpy.context, "scene", None)


def level():
    scene = _scene()
    return LEVELS.get(getattr(scene, "tcb_log_level", "verbose"), 2)


def _stamp():
    now = time.time()
    scene = _scene()
    frame = getattr(scene, "frame_current", 0) if scene is not None else 0
    return "%s.%03d [f%d]" % (time.strftime("%H:%M:%S", time.localtime(now)),
                               int((now % 1.0) * 1000), frame)


def _push(line):
    _buf.append(line)
    if len(_buf) > MAX_BUFFER:
        del _buf[:len(_buf) - MAX_BUFFER]


def _close_repeat():
    if _last["count"] > 0:
        _push("%s   ... то же сообщение ещё ×%d" % (_stamp(), _last["count"]))
    _last["count"] = 0


def add(lvl, msg):
    """lvl: 1 — основное, 2 — подробно."""
    if level() < lvl:
        return
    msg = str(msg)
    if msg == _last["msg"]:
        _last["count"] += 1
        return
    _close_repeat()
    _last["msg"] = msg
    for part in msg.split("\n"):
        _push("%s %s" % (_stamp(), part))


def get_text(create=True):
    try:
        text = bpy.data.texts.get(TEXT_NAME)
        if text is None and create:
            text = bpy.data.texts.new(TEXT_NAME)
            text.use_fake_user = True
        return text
    except Exception:
        return None


def flush(close=False):
    """Записать накопленное в текстовый блок. Безопасно вызывать часто.

    Счётчик повторов НЕ закрывается при обычном flush: тики идут один за
    другим, и «×N» должно копиться между ними. close=True закрывает его
    (перед показом журнала)."""
    if close:
        _close_repeat()
        _last["msg"] = None
    if not _buf:
        return
    text = get_text()
    if text is None:
        return                       # нет доступа к данным: повторим позже
    lines = list(_buf)
    del _buf[:]
    try:
        # text.write пишет туда, где стоит курсор редактора: ставим в конец,
        # иначе строки вставлялись бы в середину, если ты кликнул в журнале
        try:
            last = len(text.lines) - 1
            text.cursor_set(last, character=len(text.lines[last].body))
        except Exception:
            pass
        text.write("\n".join(lines) + "\n")
        if len(text.lines) > MAX_LINES:
            body = [ln.body for ln in text.lines]
            text.from_string("\n".join(body[-TRIM_TO:]))
    except Exception:
        _buf[:0] = lines             # не потерять строки, если запись не вышла


def clear():
    del _buf[:]
    _last["msg"] = None
    _last["count"] = 0
    text = get_text(create=False)
    if text is not None:
        try:
            text.clear()
        except Exception:
            pass


def show(context):
    """Показать журнал в любом открытом Text Editor. Возвращает True/False."""
    text = get_text()
    if text is None:
        return False
    flush(close=True)
    shown = False
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != "TEXT_EDITOR":
                continue
            space = area.spaces.active
            space.text = text
            shown = True
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
            try:
                with context.temp_override(window=window, area=area,
                                           region=region, space_data=space):
                    bpy.ops.text.move(type="FILE_BOTTOM")
            except Exception:
                pass
            area.tag_redraw()
    return shown
