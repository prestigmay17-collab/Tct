# -*- coding: utf-8 -*-
"""
Математика типов касательных. Без зависимостей от bpy — чистый Python.

Все наклоны в единицах «значение за кадр». Дальше Blender-движок переводит
их в точки Безье: dx = dt/3, dy = slope * dx — это в точности кубический
Hermite (проверено: расхождение с fcurve.evaluate ~1e-6).
"""

import math

TYPE_LABELS = {
    "maya_auto":  "Maya Auto (без перелётов)",
    "spline":     "Spline (Catmull-Rom)",
    "max_smooth": "Max Smooth (плоские концы)",
    "monotone":   "Monotone (PCHIP)",
    "tcb":        "TCB (Tension / Continuity / Bias)",
}

TYPE_ORDER = ("maya_auto", "spline", "max_smooth", "monotone", "tcb")

PARAMETRIC_TYPES = frozenset({"tcb"})
END_MODES = ("flat", "mirror")


def clamp_unit(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return 0.0
    if value != value:
        return 0.0
    return max(-1.0, min(1.0, value))


def _chords(times, values):
    return [(values[i + 1] - values[i]) / (times[i + 1] - times[i])
            for i in range(len(times) - 1)]


def _slopes_maya_auto(times, values):
    """Maya Auto: центральная разность, 0 в экстремумах/плато/на краях,
    плюс кламп 3*min(|d_prev|,|d_next|) — предел Fritsch–Carlson."""
    n = len(times)
    m = [0.0] * n
    for i in range(1, n - 1):
        dt_prev = times[i] - times[i - 1]
        dt_next = times[i + 1] - times[i]
        d_prev = (values[i] - values[i - 1]) / dt_prev
        d_next = (values[i + 1] - values[i]) / dt_next
        if d_prev * d_next <= 0.0:
            continue
        slope = (values[i + 1] - values[i - 1]) / (times[i + 1] - times[i - 1])
        limit = 3.0 * min(abs(d_prev), abs(d_next))
        m[i] = max(-limit, min(limit, slope))
    return list(m), list(m)


def _slopes_spline(times, values):
    n = len(times)
    m = [0.0] * n
    for i in range(1, n - 1):
        m[i] = (values[i + 1] - values[i - 1]) / (times[i + 1] - times[i - 1])
    m[0] = (values[1] - values[0]) / (times[1] - times[0])
    m[-1] = (values[-1] - values[-2]) / (times[-1] - times[-2])
    return list(m), list(m)


def _slopes_max_smooth(times, values):
    n = len(times)
    m = [0.0] * n
    for i in range(1, n - 1):
        m[i] = (values[i + 1] - values[i - 1]) / (times[i + 1] - times[i - 1])
    return list(m), list(m)


def _slopes_monotone(times, values):
    n = len(times)
    d = _chords(times, values)
    m = [0.0] * n
    m[0] = d[0]
    m[-1] = d[-1]
    for i in range(1, n - 1):
        if d[i - 1] * d[i] <= 0.0:
            m[i] = 0.0
        else:
            m[i] = (d[i - 1] + d[i]) / 2.0
            limit = 3.0 * min(abs(d[i - 1]), abs(d[i]))
            m[i] = max(-limit, min(limit, m[i]))
    return list(m), list(m)


def _slopes_tcb(times, values, t=0.0, c=0.0, b=0.0, ends="flat"):
    """
    Kochanek-Bartels в параметрическом времени.

    Классические веса (статья 1984, как в 3ds Max):
      in  = (1-T)(1-C)(1+B)/2 * d_prev + (1-T)(1+C)(1-B)/2 * d_next
      out = (1-T)(1+C)(1+B)/2 * d_prev + (1-T)(1-C)(1-B)/2 * d_next

    В статье ключи идут через равные интервалы ПАРАМЕТРА, поэтому разности
    значений и наклоны там одно и то же. На реальной кривой кадры стоят
    неравномерно, и если смешивать наклоны (значение/кадр) с весами напрямую,
    вес короткого сегмента получается таким же, как у длинного. Один и тот же
    путь значений 0->1->4 давал наклон 0.80 при t=[0,1,5] и 2.45 при t=[0,4,5]
    (при C=0.6) — расхождение втрое.

    Поэтому приращения значений нормируются на длину ОБОИХ соседних сегментов
    (span = dt_prev + dt_next), а не на каждый свой. Тогда одинаковый путь
    значений даёт одинаковый наклон при любой расстановке ключей, а на
    равномерных ключах формула совпадает с классической до последнего бита
    (проверено на T/C/B = 0, 0.3/0.2/-0.1, 0.5/0.6/0.4, -0.5/-0.3/0.9).
    """
    n = len(times)
    t, c, b = clamp_unit(t), clamp_unit(c), clamp_unit(b)
    ins = [0.0] * n
    outs = [0.0] * n

    in_prev = (1.0 - t) * (1.0 - c) * (1.0 + b) / 2.0
    in_next = (1.0 - t) * (1.0 + c) * (1.0 - b) / 2.0
    out_prev = (1.0 - t) * (1.0 + c) * (1.0 + b) / 2.0
    out_next = (1.0 - t) * (1.0 - c) * (1.0 - b) / 2.0

    for i in range(1, n - 1):
        # Приращения значений в общей параметризации: делим на длину ОБОИХ
        # сегментов, поэтому вес w1/w2 означает одно и то же на обоих.
        span = times[i + 1] - times[i - 1]
        delta_prev = (values[i] - values[i - 1]) / span
        delta_next = (values[i + 1] - values[i]) / span
        # *2 возвращает масштаб статьи (там сумма весов при T=0 равна 1
        # на среднем из двух приращений), а деление на span переводит
        # приращение в значение/кадр.
        ins[i] = (in_prev * delta_prev + in_next * delta_next) * 2.0
        outs[i] = (out_prev * delta_prev + out_next * delta_next) * 2.0

    if ends == "mirror":
        d0 = (values[1] - values[0]) / (times[1] - times[0])
        dn = (values[-1] - values[-2]) / (times[-1] - times[-2])
        ins[0] = outs[0] = (in_prev + in_next) * d0
        ins[-1] = outs[-1] = (out_prev + out_next) * dn

    return ins, outs



_DISPATCH = {
    "maya_auto": lambda ts, vs, p: _slopes_maya_auto(ts, vs),
    "spline": lambda ts, vs, p: _slopes_spline(ts, vs),
    "max_smooth": lambda ts, vs, p: _slopes_max_smooth(ts, vs),
    "monotone": lambda ts, vs, p: _slopes_monotone(ts, vs),
    "tcb": lambda ts, vs, p: _slopes_tcb(ts, vs, p.get("t", 0.0),
                                         p.get("c", 0.0), p.get("b", 0.0),
                                         p.get("ends", "flat")),
}


def slopes(times, values, kind, params=None):
    times = [float(x) for x in times]
    values = [float(v) for v in values]
    if len(times) != len(values):
        raise ValueError("times/values разной длины")
    if len(times) < 2:
        return [0.0] * len(times), [0.0] * len(times)
    for i in range(1, len(times)):
        if times[i] - times[i - 1] <= 0.0:
            raise ValueError("времена ключей не возрастают")
    if kind not in _DISPATCH:
        raise ValueError("неизвестный тип: %r" % (kind,))
    return _DISPATCH[kind](times, values, params or {})


def hermite(t, times, values, in_s, out_s):
    n = len(times)
    if t <= times[0]:
        return values[0] + out_s[0] * (t - times[0])
    if t >= times[-1]:
        return values[-1] + in_s[-1] * (t - times[-1])
    for i in range(n - 1):
        if times[i] <= t <= times[i + 1]:
            dt = times[i + 1] - times[i]
            u = (t - times[i]) / dt
            u2, u3 = u * u, u * u * u
            return ((2 * u3 - 3 * u2 + 1) * values[i]
                    + (u3 - 2 * u2 + u) * dt * out_s[i]
                    + (-2 * u3 + 3 * u2) * values[i + 1]
                    + (u3 - u2) * dt * in_s[i + 1])
    return values[-1]


def handles_for(times, values, in_s, out_s):
    """(dx, dy) левой и правой ручки в единицах Blender (кадры, значение)."""
    n = len(times)
    result = []
    for i in range(n):
        dt_in = (times[i] - times[i - 1]) if i > 0 else (times[1] - times[0])
        dt_out = (times[i + 1] - times[i]) if i < n - 1 else (times[-1] - times[-2])
        dx_in = max(abs(dt_in), 1e-4) / 3.0
        dx_out = max(abs(dt_out), 1e-4) / 3.0
        result.append((dx_in, in_s[i] * dx_in, dx_out, out_s[i] * dx_out))
    return result
