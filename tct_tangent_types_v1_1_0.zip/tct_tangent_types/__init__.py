# -*- coding: utf-8 -*-
"""
TCT для Blender — свои типы касательных в Graph Editor.

Пять алгоритмов: Maya Auto, Spline, Max Smooth, Monotone, TCB. Тип хранится
на Action (строка JSON в свойстве `tcb_config`), поэтому переезжает вместе с
файлом. Ручки Безье ставятся как dx = dt/3, dy = slope*dx — это в точности
кубический Hermite.

Меню: Graph Editor → правая кнопка / меню Channel, а также панель TCT в
сайдбаре Graph Editor и 3D-вьюпорта.
"""

bl_info = {
    "name": "TCT — Tangent Types",
    "author": "TCT",
    "version": (1, 1, 0),
    "blender": (4, 4, 0),
    "location": "Graph Editor > Channel / ПКМ; сайдбар TCT",
    "description": "Свои типы касательных: Maya Auto, Spline, Max Smooth, Monotone, TCB",
    "category": "Animation",
}

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty

from . import engine, log, mathcore, ui


CLASSES = (
    ui.TCB_OT_set_type,
    ui.TCB_OT_apply,
    ui.TCB_OT_clear,
    ui.TCB_OT_retime,
    ui.TCB_OT_diagnose,
    ui.TCB_OT_selftest,
    ui.TCB_OT_toggle_live,
    ui.TCB_OT_log_show,
    ui.TCB_OT_log_clear,
    ui.TCB_PT_graph,
    ui.TCB_PT_view3d,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.tcb_t = FloatProperty(
        name="Tension", default=0.0, min=-1.0, max=1.0, precision=2)
    bpy.types.Scene.tcb_c = FloatProperty(
        name="Continuity", default=0.0, min=-1.0, max=1.0, precision=2)
    bpy.types.Scene.tcb_b = FloatProperty(
        name="Bias", default=0.0, min=-1.0, max=1.0, precision=2)
    bpy.types.Scene.tcb_ends = EnumProperty(
        name="Крайние ключи",
        items=[("flat", "Плоские", "Плавный старт и финиш"),
               ("mirror", "Зеркальные", "Край как внутренний ключ")],
        default="flat")
    bpy.types.Scene.tcb_live = BoolProperty(
        name="Живой пересчёт", default=True,
        description="Пересчитывать касательные при правке ключей")

    bpy.types.Scene.tcb_auto = BoolProperty(
        name="Тип для новых ключей", default=True,
        description="Кривой без типа, в которую вставили ключ, назначается "
                    "активный тип, и вся кривая пересчитывается заново")
    bpy.types.Scene.tcb_active = EnumProperty(
        name="Активный тип",
        items=[(k, mathcore.TYPE_LABELS[k], "") for k in mathcore.TYPE_ORDER],
        default="maya_auto")

    bpy.types.Scene.tcb_enabled = BoolProperty(
        name="TCT включён", default=True,
        description="Главный выключатель: пока выключен, аддон ничего не "
                    "пересчитывает и не назначает",
        update=lambda self, context: engine.on_enabled_changed(self))
    bpy.types.Scene.tcb_log_level = EnumProperty(
        name="Журнал",
        items=[("off", "Журнал: выкл", "Ничего не писать"),
               ("basic", "Журнал: основное",
                "Операторы, пересчёты кривых, автотип, ошибки"),
               ("verbose", "Журнал: подробно",
                "Плюс причины пропусков, ключи, наклоны и ручки")],
        default="verbose")

    log.add(1, "=== TCT %s: регистрация ===" % ".".join(
        str(n) for n in bl_info["version"]))
    ui.register_menus()
    engine.register_handler()


def unregister():
    engine.unregister_handler()
    ui.unregister_menus()

    for prop in ("tcb_t", "tcb_c", "tcb_b", "tcb_ends", "tcb_live",
                 "tcb_auto", "tcb_active", "tcb_enabled",
                 "tcb_log_level"):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
